iimport java.util.Scanner;

public class Email {
    private String firstName;
    private String lastName;
    private String department;
    private String password;
    private int passwordLength = 10;
    private int capacity;
    private String email;
    private String altEmail;
    private String company = "Aeycompany.com";

    public Email(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;

        System.out.println("Email created: " + firstName + " " + lastName);
        this.department = setDepartment();
        System.out.println("Your department is: " + department);
        this.password = randomPassword(passwordLength);
        System.out.println("Your password is: " + password);

        email = firstName.toLowerCase() + "." + lastName.toLowerCase() + "@" + company;
        System.out.println("Your email is " + email);
    }


    private String randomPassword(int length) {
        String passwordSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.%&@#";
        char[] password = new char[length];
        for (int i = 0; i < length; i++) {
            int random = (int) (Math.random() * passwordSet.length());
            password[i] = passwordSet.charAt(random);

        }
        return new String(password);

    }

    private String setDepartment() {
        System.out.print("Department code: \n1 for Sales \n2 for Development \n3 for Accounting \n0 for none \n Pick a department");
        Scanner scanner = new Scanner(System.in);

        int department = scanner.nextInt();
        if (department == 1) {
            return "Sales";
        } else if (department == 2) {
            return "Development";
        } else if (department == 3) {
            return "Accounting";
        } else {
            return "None";
        }
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setAltEmail(String altEmail) {
        this.altEmail = altEmail;
    }

    public void changePassword(String password) {
        this.password = password;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getAltEmail() {
        return altEmail;
    }

    public String getChangedPassword() {
        return password;
    }
public void display(){
        System.out.println("Your name and last name is: "+firstName +lastName+"\n"+
                "Your department is:"+department+"\n"
                        +"Your email is:"+email);
}


}
