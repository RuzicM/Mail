public class TestClass {
    public static void main(String[] args) {
        Email email = new Email("Mico", "Ruzic");
email.display();
    }
}
